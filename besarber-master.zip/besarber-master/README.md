Social media dashboard built during my NextJS Crash Course series on [YouTube](https://youtube.com/benjamincarlson).

## Usage

1. `git clone https://github.com/bjcarlson42/nextjs-social-dashboard.git`
2. edit `.env` to have your api keys
3. `yarn`
4. `yarn dev`

Want to follow along? Watch the NextJS series here: https://www.youtube.com/playlist?list=PLL1pJgYmqo2vYtT0v_7axfIG86fyL1whf